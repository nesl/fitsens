The file js.jar provided in this directory is an unmodified binary
taken from the Rhino 1.5R5 release.  It is provided here solely
for support of the tools residing in the edu.cmu.sphinx.tools.tags
package, and is made available under the NPL 1.1 license which can
be found at http://www.mozilla.org/NPL/.
