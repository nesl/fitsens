package demo.sphinx.helloworld2;

import java.io.Reader;
import java.io.BufferedReader;
import java.io.IOException;
/**
 * Provides a BufferedReader with a readLine method that
 * blocks for only a specified number of seconds. If no
 * input is read in that time, a specified default
 * string is returned. Otherwise, the input read is returned.
 * Thanks to Stefan Reich 
 * for suggesting this implementation.
 * @author: Anthony J. Young-Garner
 * @author: Roseanne Zhang made improvement.
 */

public class TimedBufferedReader extends BufferedReader 
{
  private int    timeout    = 10; // 10 seconds
  private String defaultStr = "Y";
    	  	
  /**
   * TimedBufferedReader constructor.
   * @param in Reader
   */
  TimedBufferedReader(Reader in) 
  {
    super(in);
  }

  /**
   * TimedBufferedReader constructor.
   * @param in Reader
   * @param sz int Size of the input buffer.
   */
  TimedBufferedReader(Reader in, int sz) 
  {
    super(in, sz);
  }

  /**
   * Sets number of seconds to block for input.
   * @param seconds int
   */
  public void setTimeout(int timeout) 
  {
    this.timeout=timeout;
  }

  /**
   * Sets defaultStr to use if no input is read.
   * @param str String
   */
  public void setDefaultStr(String str) 
  {
    defaultStr = str;
  }
    	  
  /**
   * We use ms internally
   * @return String
   */
  public String readLine() throws IOException 
  {
    int waitms = timeout*1000;
    int ms     = 0;
    while (!this.ready()) 
    {
      try 
      { 
        Thread.currentThread().sleep(10);
        ms += 10;
      }
      catch (InterruptedException e) 
      { 
        break; 
      }
      if (ms >= waitms) 
      {
      	return defaultStr;
      }
    }
    return super.readLine();
  }

  public int read() throws IOException 
  {
    int waitms = timeout*1000;
    int ms     = 0;
    while (!this.ready()) 
    {
      try 
      { 
        Thread.currentThread().sleep(10);
        ms += 10;
      }
      catch (InterruptedException e) 
      { 
        break; 
      }
      if (ms >= waitms) 
      {
      	return -1;
      }
    }
    return super.read();
  }  
  
}