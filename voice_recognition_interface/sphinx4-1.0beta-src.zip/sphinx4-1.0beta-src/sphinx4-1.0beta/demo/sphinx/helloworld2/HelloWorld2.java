/*
 * Copyright 1999-2004 Carnegie Mellon University.
 * Portions Copyright 2004 Sun Microsystems, Inc.
 * Portions Copyright 2004 Mitsubishi Electric Research Laboratories.
 * All Rights Reserved.  Use is subject to license terms.
 *
 * See the file "license.terms" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *
 */
package demo.sphinx.helloworld2;

import edu.cmu.sphinx.result.ConfidenceResult;
import edu.cmu.sphinx.result.ConfidenceScorer;
import edu.cmu.sphinx.result.Path;
import edu.cmu.sphinx.result.WordResult;
import edu.cmu.sphinx.frontend.util.Microphone;
import edu.cmu.sphinx.recognizer.Recognizer;
import edu.cmu.sphinx.result.Result;
import edu.cmu.sphinx.util.props.ConfigurationManager;
import edu.cmu.sphinx.util.props.PropertyException;

import java.io.File;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.util.Date;

/**
 * A simple HelloWorld demo showing a simple speech application 
 * built using Sphinx-4. This application uses the Sphinx-4 endpointer,
 * which automatically segments incoming audio into utterances and silences.
 */
public class HelloWorld2 {
	
    /**
     * Main method for running the HelloWorld demo.
     */
    public static void main(String[] args) {
        try {
            URL url;
            if (args.length > 0) {
                url = new File(args[0]).toURI().toURL();
            } else {
                url = HelloWorld2.class.getResource("helloworld2.config.xml");
            }

            System.out.println("Loading...");

            ConfigurationManager cm = new ConfigurationManager(url);

	    Recognizer recognizer = (Recognizer) cm.lookup("recognizer");
	    Microphone microphone = (Microphone) cm.lookup("microphone");


            /* allocate the resource necessary for the recognizer */
            recognizer.allocate();

            /* the microphone will keep recording until the program exits */
	    if (microphone.startRecording()) {

		while (true) {
		// If request an input
// 		    System.out.println
// 			("Press [ENTER] and then Say Your Name. \n"  +
//                          "(David|Jason|Jonathan|Kim|Mani|Rahul|Roy|Sadaf|Sasank|Thomas|Young|Zainul)");
//                     
// 			// to press A key and then start recording                         
//                     TimedBufferedReader stdin_block = new TimedBufferedReader(new InputStreamReader(System.in));
//                     int sb = -1;
//                     while(sb == -1) {
//                     	//System.out.println("clear cache " + sb);
//                     	microphone.clear();
//                     	sb = stdin_block.read();
//             	    }
//                     System.out.println("START... ");

                    // clear all audio cache
    		    microphone.clear();
                         
                    /*
                     * This method will return when the end of speech
                     * is reached. Note that the endpointer will determine
                     * the end of speech.
                     */ 
		    Result result = recognizer.recognize();
		    
		    if (result != null) {
			
			String resultText = result.getBestFinalResultNoFiller();
			String curtime = DateFormat.getDateTimeInstance().format(new Date());
			
			if(resultText.compareTo("") == 0)
				continue;
			
			System.out.println("\n\nhi " + resultText.toUpperCase() + " !!  hi " + resultText.toUpperCase() + " !!\n" );
// 			System.out.println("\tif NAME is INCORRECT");
// 			System.out.println("\t\t==> press \"n\" and hit [ENTER] (within 10 secs)");
// 			System.out.println("\tif NAME is CORRECT\n\t\t==> feel free to take the measurements.\n");

			
			 // create a BufferedReader input stream attached to the keyboard
			 // this is used for user feedback of the correctness in recognized name
// 			int name_error = 0;
// 			TimedBufferedReader stdin = new TimedBufferedReader(new InputStreamReader(System.in));
// 			try {
// 				String yn = stdin.readLine();
// 				if(yn.compareToIgnoreCase("n") == 0)
// 				{
// 					System.out.println("Sorry about that... Please try again ");
// 					name_error = 1;
// 					java.lang.Thread.sleep(700);
// 				}
// 				else {
// 					System.out.println("I guess I am right on who you are :)");
// 					java.lang.Thread.sleep(2000);
// 				}
// 				
//  				for(int i=0; i<3; i++)
//  					System.out.println();

// 			}  catch (IOException ioe) {
// 				System.out.println("Recieved exception: "+ioe);
// 				System.exit(1);
// 			} catch (InterruptedException e) {
// 			}
			
			
					// what's my confidence level??
			// 			ConfidenceScorer cs = (ConfidenceScorer) cm.lookup ("confidenceScorer");
			// 			if(cs == null) { System.out.println("found no scorer"); }
			//                         ConfidenceResult cr = cs.score(result);
			//                         Path bestPath = cr.getBestHypothesis();
			//                         double pathConfidence = bestPath.getConfidence();
			// 			System.out.println("path confidence:" + pathConfidence);
			//                         
			//                         // confidence for each word in best path
			// 			WordResult[] words = bestPath.getWords();
			// 			for (int i = 0; i < words.length; i++) {
			// 				WordResult wordResult = (WordResult) words[i];
			// 				double wordConfidence = wordResult.getConfidence();
			// 				
			// 				String word = wordResult.getPronunciation().getWord().getSpelling();
			//         			System.out.println(" " + word + " " + wordConfidence);
			// 			}			
			
			try {
				BufferedWriter out = new BufferedWriter(new FileWriter("continuous_rec.txt", true));
				out.write(curtime + "\n" + resultText);
// 				if(name_error == 1)
// 				{	out.write(" (Wrong)\n\n");	}
// 				else
				{	out.write("\n\n");	}
				out.close();
			} catch (IOException e) {
			}
		    } else {
			System.out.println("I can't hear what you said.\n");
		    }
		}
	    } else {
		System.out.println("Cannot start microphone.");
		recognizer.deallocate();
		System.exit(1);
	    }
        } catch (IOException e) {
            System.err.println("Problem when loading HelloWorld2: " + e);
            e.printStackTrace();
        } catch (PropertyException e) {
            System.err.println("Problem configuring HelloWorld2: " + e);
            e.printStackTrace();
        } catch (InstantiationException e) {
            System.err.println("Problem creating HelloWorld2: " + e);
            e.printStackTrace();
        }
    }
}
